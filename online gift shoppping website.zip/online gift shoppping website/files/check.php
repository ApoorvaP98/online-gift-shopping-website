<?php
ob_start();
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="register"; // Database name 
$tbl_name="reg"; // Table name

// Connect to server and select databse.
$conn = new mysqli($host, $username, $password, $db_name)or die(mysql_error());
//echo "Connected to MySQL<br />";
mysqli_select_db($conn,"$db_name") or die(mysql_error());
//echo "Connected to Database<br />";
// Check $username and $password 
/*
if(empty($_POST['username']))
{
    echo "UserName/Password is empty!";
    return false;
}
if(empty($_POST['password']))
{
    echo "Password is empty!";
    return false;
}
*/

// Define $username and $password 
$username=$_POST['username'];
$password=$_POST['password'];
// To protect MySQL injection (more detail about MySQL injection)

/*$username = stripslashes($username);
$password = stripslashes($password);
$username = mysqli_real_escape_string($conn,$username);
$password = mysqli_real_escape_string($conn,$password);

$sql="SELECT * FROM $tbl_name WHERE username='$username' and password='$password'";
$result=mysqli_query($conn,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
// If result matched $username and $password, table row must be 1 row
if ($count==1) {
    echo "Success! $count";
} else {
    echo "Unsuccessful! $count";
}

ob_end_flush();*/
$sql="SELECT * FROM $tbl_name WHERE email='$username'";
$result=mysqli_query($conn,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
// If result matched $username and $password, table row must be 1 row
//if($count==1){
    $row = mysqli_fetch_assoc($result);
    if ( $password == $row['password']){
         
        header('location:shopping.html');
    }
    else {
        echo "wrong password";
        return false;
    }
//}
//else{
   // echo "Wrong Username or Password";
    //return false;
//}
?>