<?php
$name = $_POST['name'];
$house_no = $_POST['house_no'];
$area = $_POST['area'];
$city = $_POST['city'];
$state = $_POST['state'];
$pincode = $_POST['pincode'];
$items = $_POST['items'];
if (!empty($house_no) ) {
 $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "register";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
        $bill=$items*99;
        
echo "$name.<br />";
echo "House No:$house_no.<br />";
echo "$area $city $state.<br />";
echo "PIN:$pincode.<br />";
echo "Total amount:$bill";
    }
}
?>