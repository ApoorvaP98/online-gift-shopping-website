
<html>

    <head>
    
        <title>Register!</title>
        
        <style type="text/css">
        
            body{
                
                margin: 0;
                
                padding: 0;
                
                font-family: helvetica;
            
            }
            
            #topBar{
                
                width: 100%;
                
                height: 200px;
                
                background-color: yellow;
                
            }
            
            .pageContainer{
                
                width: 1200px;
                
                margin: 0 auto;
                
            }
            
            
            h1{
                
                text-align: center;
                
                position:relative;
                
                top: 20px;
                
                font-size: 60px;
                
            }
            
            h2{
                text-align: center;
                
                font-size: 23px;
                
                font-weight: 100;
            }
            
            #topBarHr{
                
                width: 400px;
                
                height: 1px;
                
                border: none;
                
                background-color: black;
            }
            
            #registerForm{
                
                background-color: aqua;
                
                height: 460px;
                
                margin: 0 auto;
                
                text-align: center;
                
            }
            
            table{
                
                text-align: center;
                
                margin: 0 auto;
                
                position: relative;
                
                top: 30px;
                
            }
            
            td{
                
                font-size: 20px;
                
                padding: 10px;
                                
            }
            
            input{
                
                padding: 10px;
                
                border-radius: 100px;
                
                border: none;
                
                font-size: 20px;
                
            }
            
            button{
                
                background-color: #FF3E41;
                
                border: none;
                
                padding: 15px 30px;
                
                color: white;
                
                font-size: 20px;
                
                border-radius: 100px;
                
                margin-top: 10px;
                
                text-align: center;
                
            }
            
            p{
                
                margin-top: 50px;
                
            }
        
        </style>
    
    </head>
    
    <body>
        
        <div id="topBar">
            
            <div class="pageContainer">

                <h1>oyehappy</h1>
                
                <hr id="topBarHr">
                
                <h2>Register</h2>

            </div>
    
        </div>
        <form action="insert.php" method="POST">
        <div id="registerForm">
        
            <div class="pageContainer">

                
                    
                    <table>
                
                        <tr>

                            <td>FULL NAME</td>

                            <td>MOBILE NUMBER</td>

                        </tr>

                        <tr>

                            <td><input type="text" placeholder="John Wick" required name="username"></td>

                            <td><input type="tel" placeholder="+91" required name="mobile"></td>

                           

                        </tr>

                        <tr>

                            <td>EMAIL</td>

                            <td>PASSWORD</td>

                        </tr>
                        

                        <tr>

                            <td><input type="email" placeholder="johnwick@mail.com" required name="email"></td>

                            <td><input type="password" placeholder="**********" required name="password"></td>

                        </tr>
                        <tr>
                            <td>phone code</td>
                            <td>gender</td>
                        
                        </tr>
                        <tr>
                            <td><input type="text" placeholder="574202" required name="phoneCode"></td>
                            <td><input type="text" placeholder="M or F" required name="gender"></td>
                        </tr>
                    </table>
					<p>
					<input id="submitbtn"  name="Submit" type="submit" value="Submit" formaction="insert.php">
					</p>
            </div>
            
        </div>
		</form>
        
        
    </body>

</html>