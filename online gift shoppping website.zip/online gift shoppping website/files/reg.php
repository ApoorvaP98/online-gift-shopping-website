<html>
<body>

Welcome <?php echo $_POST["name"]; ?>!
Your email address is <?php echo $_POST["email"]; ?> 

</body>
</html> 