<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<style >
body{
background-color: orange;
                margin:0;
                
                padding:0;
                
                font-family: helvetica;
            }
			button{
                
                background-color: #c3cfef;
                
                padding: 10px 20px;
                
                color:black;
                
                border: none;
                
                border-radius: 10%;
            }
#topYellowBar{
                
                width:100%;
                
                height: 200px;
                
                background-color:yellow;
            
            }
            
            .pageContainer{
                
                width: 1200px;
                
                margin:0 auto;
            }
			#topBarHr{
                
                width: 400px;
                
                height: 1px;
                
                border: none;
                
                background-color: black;
            }
			 h1{
                
                text-align: center;
                
                position:relative;
                
                top: 20px;
                
                font-size: 60px;
                
            }
            
            h2{
                text-align: center;
                
                font-size: 35px;
                
                font-weight: 100;
            }
			h3{
                
                margin-top: 0;
                
                position: relative;
                
                top: 15px;
                
                text-align: center;
                
                color: black;
                
                font-size: 25px;                               
            }
			div.absolute {
			position: absolute;
			width: 30%;
			bottom: 10px;
			border: black;
			}
			
</style>
<body>
 <div id="topYellowBar">
        <div class="pageContainer">
            <h1 align="center"><dt>oyehappy</dt></h1></br>
            <hr id="topBarHr">
            <h2 align="center">Flowers Anytime Anywhere</h2>    
        </div>
 </div>
 <div align='center';>
 <?php
 
$name = $_POST['name'];
$house_no = $_POST['house_no'];
$area = $_POST['area'];
$city = $_POST['city'];
$state = $_POST['state'];
$pincode = $_POST['pincode'];
$items = $_POST['items'];
if (!empty($name) || !empty($house_no) || !empty($area) || !empty($city) || !empty($state) || !empty($pincode) || !empty($items)) 
    {
 $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "register";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
        $bill=$items*99;
        echo "Address:";
        
echo "$name.<br />";
echo "House No:$house_no.<br />";
echo "$area $city $state.<br />";
echo "PIN:$pincode.<br />.<br />";
echo "Total amount:$bill";
    }
}
?>

<br><br>
<!--<button align="center-left" onclick="order.html" style="border-radius:100px">Change the details</button>-->
<a href="order.html"><button style="border-radius:100px">Change the details</button></a>
</div>
</div>
 <h1 align="center">Your Order is Successfully Placed</h1>
 <h3 align="center">
	<button align="center-left" onclick="myFunction()" style="border-radius:100px">Cancel The Order</button>
	<p id="demo1"></p>
	<a href="shopping.html"><button style="border-radius:100px">Go back to shopping</button></a>
	<a href="home.html"><button style="border-radius:100px">Logout</button></a>
	
	<p><br></p>
	<select id="name1">
		<option value="a1">Item is defective</option>
		<option value="a2">Delivery date is too late</option>
		<option value="a3">Found similar product with cheaper rate</option>
	</select>
	
	<p id="demo2"></p>
</h3>



<script>
window.onload = function() 
{ 
    document.getElementById('name1').style.display = 'none';
};

function button1function(id){

    if(document.getElementById(id).style.display == 'none'){
        document.getElementById(id).style.display = 'initial';
    }else{
        document.getElementById(id).style.display = 'none';
    }
}
function myFunction() {
  document.getElementById("demo1").innerHTML = "Your order is cancelled";
}


</script>
</body>
 </html>
 
