<html>
    
    <head>
        
        <title>oyehappy</title>
        
        <style type="text/css">
            
            body{
                margin:0;
                
                padding:0;
                
                font-family: helvetica;
            }    
            
            #topYellowBar{
                
                width:100%;
                
                height: 200px;
                
                background-color:yellow;
            
            }
            
            .pageContainer{
                
                width: 1200px;
                
                margin:0 auto;
            }
            
            h1{
                
                text-align: center;
                
                position:relative;
                
                top: 20px;
                
                font-size: 60px;
                
            }
            
            h2{
                text-align: center;
                
                font-size: 23px;
                
                font-weight: 100;
            }
            
            #topBarHr{
                
                width: 400px;
                
                height: 1px;
                
                border: none;
                
                background-color: black;
            }
            
            #loginForm{
                
                height: 300px;
                
                width: 100%;
                
                background-color:aqua;
                
            }
            
            #loginFormTable{
                text-align: center;
                
                float: left;
                
                border-right: 1px grey solid;
                
                padding-right: 200px;
                
                position: relative;
                
                top: 15px;
                
                left: 130px;

            }
            
            #signUpFormTable{
                                
                margin-left: 300px;
                
                position:relative;
                
                top: 70px;
                
                float: left;
                
                text-align: center;
            }
            
            #login{
                
                position:relative;
                
                top: 5px;
            }
            
            button{
                
                background-color: #c3cfef;
                
                padding: 5px 15px;
                
                color:white;
                
                border: none;
                
                border-radius: 10%;
            }
            
            .clear{
                
                float: none;
            }
            
            #featuresBar{
                
                width: 100%;
                
                height:330px;
                
                background-color: #FF3E41;
                
            }
            
            h3{
                
                margin-top: 0;
                
                position: relative;
                
                top: 10px;
                
                text-align: center;
                
                color: white;
                
                font-size: 40px;
                
                
                
            }
            
            #featuresHr{
                
                border: none;
                
                height: 1px;
                
                background-color: white;
            }
            
            #featureTable{
                
                color: white;
                
                font-size: 30px;
                
                margin: 0 auto;
                
                text-align: center;
                
            }
            
            .featureTd{
                
                padding: 20px 170px;
            }
            .wrap{
        max-width: 500px;
        align-items: center;
        
        padding:20px;
        font-family: sans-serif;
        border-radius: 10px;
        } 
        .signUpForm{
        max-width: 500px;
        align-items: left;
        
        padding:20px;
        font-family: sans-serif;
        border-radius: 10px;
        padding-left:500px;
        } 
            
        </style>
    </head>
    <body>
        <div id="topYellowBar">
            <div class="pageContainer">
                <h1>oyehappy</h1>
                <hr id="topBarHr">
                <h2>Flowers Anytime Anywhere</h2>
                
            </div>
        </div>
        <div id="loginForm">
            <div class="wrap">
        
            <form action="#" method="POST">
    
    <p style="text-align: center; color: gray;">Fill the address:</p><hr style="color: gray;">
    <lable style="float: left;">Name:</lable>
    <input  style="float: right;" type="text" name="name"><br></br>
    <lable style="float: left;">House No.:</lable>
    <input style="float: right;" type="text" name="house_no"><br></br>
    <lable style="float: left;">Road Name:</lable>
    <input  style="float: right;" type="text" name="road"><br></br>
    <lable style="float: left;">City:</lable>
    <input style="float: right;" type="text" name="city"><br></br>
    <lable style="float: left;">State:</lable>
    <input style="float: right;" type="text" name="state"><br></br>
    <lable style="float: left;">Pincode:</lable>
    <input style="float: right;" type="text"  name="pincode"><br></br>
    </form>
        </div>
    
    
    
            <div class="signUpForm" >
                <table id="signUpFormTable">
                <h3 align="center">Mode of payment:</h3>
                    <p align="center">
                      <select required>
                        <option value="cod">Cash on delivery</option>
                        <option value="upi"> UPI</option>
                        <option value="card">Debit card or Credit card</option>
                      </select>	
                    </p>
                <lable style="float: left;">No. of Items:</lable>
    <input  style="float: right;" type="text" name="name"><br></br>
    

                    </table>
            </div>
        </div>
        
    </body>
</html>